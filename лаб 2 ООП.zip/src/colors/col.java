package colors;

public enum col {
    TRANSPARENT,
    RED,
    GREEN,
    BLUE,
    PERPLE,
    WHITE,
    BLACK,
    YELLOW,
    BROWN

}
