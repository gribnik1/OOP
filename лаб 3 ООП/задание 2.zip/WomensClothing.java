public interface WomensClothing {
    void dressWomen();
}
