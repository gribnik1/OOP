public interface MensClothing {
    void dressMen();
}
